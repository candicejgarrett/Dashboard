<?php 
require('../../../connect.php');
require('../../../header.php');
$type=$_POST['type'];

if ($type=="newLHN") {
	$lhnTitle = addslashes($_POST['lhnTitle']);
	$insert = mysqli_query($connection,"INSERT INTO `Live LHNs`(`Title`, `Status`) VALUES('$lhnTitle','New')");
	
	$lhnID = $connection->insert_id;
	


	////////////
	
	$results = ["lhnID" => $lhnID,"array" => $linkList,"linkHref" => $linkHref];
	
	header('Content-Type: application/json'); 
	echo json_encode($results);
}

if ($type=="updateLHN") {
	$lhnNewTitle = addslashes($_POST['lhnNewTitle']);
	$lhnID = $_POST['lhnID'];
	$update = mysqli_query($connection,"UPDATE `Live LHNs` SET `Title`='$lhnNewTitle' WHERE `lhnID`='$lhnID'");

	////////////
	
	$results = ["lhnID" => $lhnID];
	
	header('Content-Type: application/json'); 
	echo json_encode($results);
}

if ($type=="deleteLHN") {
	$lhnID=$_POST['lhnID'];
	//deleting headers
	$deleteHeaders = "DELETE FROM `Live LHN Headers` WHERE `lhnID` = '$lhnID'";
	$deleteHeaders_result = mysqli_query($connection, $deleteHeaders) or die ("Query to get data from Team Project failed: ".mysql_error());

	//LINKS
	$deleteLinks = "DELETE FROM `Live LHN Links` WHERE `lhnID` = '$lhnID'";
	$deleteLinks_result = mysqli_query($connection, $deleteLinks) or die ("Query to get data from Team Project failed: ".mysql_error());
	
	//PERMISSIONS
	$deletePermissions = "DELETE FROM `Live LHN Permissions` WHERE `lhnID` = '$lhnID'";
	$deletePermissions_result = mysqli_query($connection, $deletePermissions) or die ("Query to get data from Team Project failed: ".mysql_error());

	//ACTUAL LHN
	$deleteLHN = "DELETE FROM `Live LHNs` WHERE `lhnID` = '$lhnID'";
	$deleteLHN_result = mysqli_query($connection, $deleteLHN) or die ("Query to get data from Team Project failed: ".mysql_error());
	
}

?>