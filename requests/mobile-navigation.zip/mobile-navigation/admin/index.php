<?php 
include_once('../../../header.php');

if ($myRole === 'Admin' || $myRole === 'Editor') {
 
}
else {
	header("location:/dashboard/404/no-access.php"); 	
}
?>
   <html>
    <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php echo $stylesjs ?>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<style>
	.hoverState {
		background-color: rgba(0,0,0,0.3);
	}
	.reviewerEmails span {
		font-weight:bold;
		font-style: italic;
	}
	.overviewSlid .row {
		margin-top:-10px !important; 
	}
</style>
<script src="/dashboard/js/csvExport.js"></script>

<script>
$(document).ready(function() {

$(document).on('click','#deleteLHN', function() {
	$("#newLHNForm,#updateLHNForm").slideUp();
	$("#deleteLHNContainer").slideToggle();
	
});
	
$(document).on('click','#deleteLHNContainer .fa', function() {
	if (confirm('Are you sure? This CANNOT be undone!')) {
		var lhnID = $("#deleteLHNSelect").val();
		
		//ajax
	var dataString = {'type':"deleteLHN",lhnID:lhnID};	
					
				$.ajax({
						type: "POST",
						url: "/dashboard/requests/lhn/admin/process.php",
						data: dataString,
						cache: false,
						success: function(results){
							
							location.reload();
						}, 
						error: function(results) {
							console.log(results);
							alert("Error.");

						}
						});
	}
});
	
$(document).on('click','#createNewLHN', function() {
	$("#deleteLHNContainer,#updateLHNForm").slideUp();
	$("#newLHNForm").slideToggle();
	
});
	
$(document).on('click','.addHeaderBox', function() {
	$(this).before('<div class="newHeaderContainer"><input type="text" class="newHeaderText" placeholder="Header Title"><div class="removeHeaderContainer">Delete Menu <i class="fa fa-minus-circle" aria-hidden="true"></i></div><div class="addLinkBox">Add Link <i class="fa fa-plus-circle" aria-hidden="true"></i></div></div>');
});
	
$(document).on('click','.addLinkBox', function() {
	$(this).before('<div class="newLinkContainer"><input type="text" class="newLinkText" placeholder="Link Title"><input type="text" class="newLinkHref" placeholder="Link Path"><div class="removeLinkContainer"><i class="fa fa-minus-circle" aria-hidden="true"></i></div></div>');
});

$(document).on('click','.removeHeaderContainer', function() {
	$(this).parent().remove();
});
	
$(document).on('click','.removeLinkContainer', function() {
	$(this).parent().remove();
});
	
// getting arrays
var headerList = [];
var linkList = [];
	
$(document).on('click','#saveNewLHN', function() {
	//validation
	$("#newLHNForm input").each(function(){
			if (!$(this).val()) {
				$(this).addClass("required");
				
				}
			else {
				$(this).removeClass("required");
			}

	});
	
	if ($("#newLHNForm input").hasClass("required")) {
		alert("Please fix errors highlighted below.");
		//return false;
		}
	//getting title
	var lhnTitle = $("#lhnTitle").val();

	//ajax
	var dataString = {'type':"newLHN",lhnTitle:lhnTitle};	
					
				$.ajax({
						type: "POST",
						url: "/dashboard/requests/lhn/admin/process.php",
						data: dataString,
						cache: false,
						success: function(results){
							
							window.location.href = "/dashboard/requests/lhn/?lhnID="+results.lhnID;

						}, 
						error: function(results) {
							console.log(results);
							alert("Error.");

						}
						});
	
	
});


$(document).on('click','#updateLHN', function() {
	$("#newLHNForm,#deleteLHNContainer").slideUp();
	$("#updateLHNForm").slideToggle();
	
});
	
$(document).on('click','#updateLHNTitle', function() {
	if (confirm('Are you sure? This CANNOT be undone!')) {
		var lhnID = $("#updateLHNSelect").val();
		
		//validation
	$("#updateLHNForm input").each(function(){
			if (!$(this).val()) {
				$(this).addClass("required");
				
				}
			else {
				$(this).removeClass("required");
			}

	});
	
	
	//getting title
	var lhnNewTitle = $("#lhnTitleNew").val();
		//ajax
	var dataString = {'type':"updateLHN",lhnID:lhnID,lhnNewTitle:lhnNewTitle};	
					
				$.ajax({
						type: "POST",
						url: "/dashboard/requests/lhn/admin/process.php",
						data: dataString,
						cache: false,
						success: function(results){
							
							window.location.href = "/dashboard/requests/lhn/?lhnID="+results.lhnID;
						}, 
						error: function(results) {
							console.log(results);
							alert("Error.");

						}
						});
	}
});	
	
});
	

	
</script>
    </head>

    <body>
    
<nav class="navbar navbar-default" style="background:#ffffff; border:none;">
  <div class="container-fluid">
   <?php include("../../../templates/topNav.php") ?>
  </div><!-- /.container-fluid -->
</nav>
<div class="container-fluid">
	<div class="row">
        <?php include("../../../templates/lhn.php") ?>
       
       <div class="col-sm-10" style="height: 100%;">
      <div class="row">
     	<div class="col-sm-12">
			<?php include("../../../templates/alerts.php") ?>
		</div>
		</div>
     	<div class="row">
		 <div class="col-sm-12">
			<div class="whitebg">
    	 		
    	 		
					<div class="header">
						<a href="/dashboard/requests/lhn" class="genericbtn" style="float:right;margin-top:-10px;">Back</a>
					<h3>LHN Requests</h3>
					
					</div>
				
					<div class="row">
						<div class="col-sm-12">
							<div id="createNewLHN" class="genericbtn" style="margin-right:10px;">Create New</div>
							<div id="updateLHN" class="genericbtn" style="margin-right:10px;">Update Title</div>
							<div id="deleteLHN" class="genericbtn redbtn" style="margin-right:10px;">Delete</div>
						</div>
					</div>
				
				<br>
					
				<div class="row">
						<div class="col-sm-12">
							
							<div id="newLHNForm">
								
								<div class="row">
									<div class="col-sm-12">
									<div class="header">

								<h3>Create a New LHN</h3>

								</div>
										</div>
									<div class="col-sm-12">
									<input type="text" placeholder="Title" id="lhnTitle">
									
									</div>
									
								</div>
								
							<div class="row">
									<div class="col-sm-12">	
										<hr>
							<div id="saveNewLHN" class="genericbtn" style="margin-right:10px;">Save</div>
							</div>
								</div>
							
							</div>
							
							
							<div id="updateLHNForm">
								
								<div class="row">
									<div class="col-sm-12">
									<div class="header">

								<h3>Update LHN Title</h3>

								</div>
										</div>
									<div class="col-sm-12">
									<div id="updateLHNContainer">
							<?php
							
								$getLHNCats = "SELECT `Live LHNs`.`lhnID`, `Title` FROM `Live LHNs`";

								$getLHNCats_result = mysqli_query($connection, $getLHNCats) or die ("getTasks_result to get data from Team Project failed: ".mysql_error());

					echo '<select id="updateLHNSelect" style="width:200px !important;"><option value="All">Select...</option>'; // Open your drop down box

								while($row = mysqli_fetch_assoc($getLHNCats_result))
								  {
									echo "<option value='" . $row['lhnID'] ."'>".$roaw['First Name']." ".$row['Title']."</option>";

								  }
									echo '</select>';					
													?>
										
										<br>
										<input type="text" placeholder="New Title" id="lhnTitleNew" style="width:200px !important;">
								
								</div>
									</div>
									
									
									
								</div>
								
							<div class="row">
									<div class="col-sm-12">	
										
							<div id="updateLHNTitle" class="genericbtn" style="margin-right:10px;margin-top:25px;">Save</div>
							</div>
								</div>
							
							</div>
							
							<div id="deleteLHNContainer">
								<div class="header">

								<h3>Delete a LHN</h3>

								</div>
							<?php
							
								$getLHNCats = "SELECT `Live LHNs`.`lhnID`, `Title` FROM `Live LHNs`";

								$getLHNCats_result = mysqli_query($connection, $getLHNCats) or die ("getTasks_result to get data from Team Project failed: ".mysql_error());

					echo '<select id="deleteLHNSelect" style="width:200px !important;"><option value="All">Select...</option>'; // Open your drop down box

								while($row = mysqli_fetch_assoc($getLHNCats_result))
								  {
									echo "<option value='" . $row['lhnID'] ."'>".$row['First Name']." ".$row['Title']."</option>";

								  //echo "<div class='lhnSelectionHeader' lhnid='".$row['lhnID']."'>";
								 // echo $row['Name'];
								 // echo "</div>";
								  }
									echo '</select>';					
													?>
								<div style="display:inline-block;color:#ff0000; font-size:20px;"><i class="fa fa-minus-circle" aria-hidden="true"></i></div>
								</div>
							<br><br>
           				</div>
     	 			</div>	
           			
    	 		
   	 	   </div>
     	 	
     	 	 
		 </div>	
     	
     	
     	
     	</div>
     
       </div>
       
      
	</div>
</div>    


   
</div>  
	   

    <?php echo $scripts?>

    </body>
</html>