<?php 
require('../../connect.php');
require('../../header.php');
require('../../emailDependents.php');
require('../../functions/global.php');

$type=$_POST['type'];
$lhnID=$_POST['lhnID'];

if ($type=="loadOverview") {
	$inProcess = "SELECT `Live LHNs`.`lhnID`, `Title`,`Live LHNs`.`Timestamp`,`Live LHNs`.`Status` FROM `Live LHNs` WHERE `Status` = 'In Process'";
	$inProcess_result = mysqli_query($connection, $inProcess) or die ("Query to get data from Team Project failed: ".mysql_error());
	$inProcessRequestsCount = mysqli_num_rows($inProcess_result);
	while($row = $inProcess_result->fetch_assoc()) {
		$lhnID = $row["lhnID"];
		$lhnName = $row["Title"];
		$lhnLastUpdated = date('m/d/Y @ g:ia',strtotime($row["Timestamp"]));
		
		$inProcessRequests[] = '
		<div class="srItem" lhnid='.$lhnID.'>
			<div class="name">'.$lhnName.'</div>
			<hr>
			<div class="timestamp">Last Updated: '.$lhnLastUpdated.'</div>
		</div>
		';
	}
	
	$approved = "SELECT `Live LHNs`.`lhnID`, `Title`,`Live LHNs`.`Timestamp`,`Live LHNs`.`Status` FROM `Live LHNs` WHERE `Status` = 'Approved'";
	$approved_result = mysqli_query($connection, $approved) or die ("Query to get data from Team Project failed: ".mysql_error());
	$approvedRequestsCount = mysqli_num_rows($approved_result);
	while($row = $approved_result->fetch_assoc()) {
		$lhnID = $row["lhnID"];
		$lhnName = $row["Title"];
		$lhnLastUpdated = date('m/d/Y @ g:ia',strtotime($row["Timestamp"]));
		
		$approvedRequests[] = '
		<div class="srItem" lhnid='.$lhnID.'>
			<div class="name">'.$lhnName.'</div>
			<hr>
			<div class="timestamp">Last Updated: '.$lhnLastUpdated.'</div>
		</div>
		';
	}
	
	
	$live = "SELECT `Live LHNs`.`lhnID`, `Title`,`Live LHNs`.`Timestamp`,`Live LHNs`.`Status` FROM `Live LHNs` WHERE `Status` = 'Live'";
	$live_result = mysqli_query($connection, $live) or die ("Query to get data from Team Project failed: ".mysql_error());
	$liveRequestsCount = mysqli_num_rows($live_result);
	while($row = $live_result->fetch_assoc()) {
		$lhnID = $row["lhnID"];
		$lhnName = $row["Title"];
		$lhnLastUpdated = date('m/d/Y @ g:ia',strtotime($row["Timestamp"]));
		
		$liveRequests[] = '
		<div class="srItem" lhnid='.$lhnID.'>
			<div class="name">'.$lhnName.'</div>
			<hr>
			<div class="timestamp">Last Updated: '.$lhnLastUpdated.'</div>
		</div>
		';
	}
	////////////
	
	$results = ["inProcessRequests" => $inProcessRequests,
				"inProcessRequestsCount" => $inProcessRequestsCount,
			   "approvedRequests" => $approvedRequests,
				"approvedRequestsCount" => $approvedRequestsCount,
			   "liveRequests" => $liveRequests,
				"liveRequestsCount" => $liveRequestsCount];
	
	header('Content-Type: application/json'); 
	echo json_encode($results);
}


if ($type=="load") {
	
	//getting all 
	$getAll = "SELECT `Live LHNs`.`lhnID`, `Title`,DATE_FORMAT(`Live LHNs`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp',`Live LHNs`.`Status` FROM `Live LHNs` WHERE `Live LHNs`.`lhnID`='$lhnID'";
	$getAll_result = mysqli_query($connection, $getAll) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getAll_result->fetch_assoc()) {
        $lhnName = $row["Title"];
		
		$lhnLastUpdated = $row["Timestamp"];
		$lhnStatus = $row["Status"];
	}
	
	//getting headers
	$getHeaders = "SELECT `Live LHN Headers`.`headerID`, `Title`,DATE_FORMAT(`Live LHN Headers`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp' FROM `Live LHN Headers` WHERE `Live LHN Headers`.`lhnID`='$lhnID' ORDER BY `Live LHN Headers`.`OrderID` ASC";
	$getHeaders_result = mysqli_query($connection, $getHeaders) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getHeaders_result->fetch_assoc()) {
        $lhnHeaderIDs[]=$row["headerID"];
	}
	
	$allItemsArray=[];
	
	if ($lhnStatus === "In Process") {
		$statusClass = 'inProcessLHN';
	}
	else if ($lhnStatus === "Approved") {
		$statusClass = 'approvedLHN';
	}
	else {
		$statusClass = 'liveLHN';
	}
	
	array_push($allItemsArray,'<div class="lhnStatus '.$statusClass.'">STATUS: '.$lhnStatus.' | <span style="font-weight:300">Last Updated @ '.$lhnLastUpdated.'</span></div><h3 class="lhnTitle">'.$lhnName.'</h3>');
	
	
	
	foreach($lhnHeaderIDs as $lhnHeaderID){
		
		//getting THIS headers info
	$getThisHeader = "SELECT `Live LHN Headers`.`headerID`, `Live LHN Headers`.`Title`,DATE_FORMAT(`Live LHN Headers`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp', `Status`, `username` FROM `Live LHN Headers` JOIN `user` ON `Live LHN Headers`.`userID` = `user`.`userID` WHERE `Live LHN Headers`.`headerID`='$lhnHeaderID'";
	$getThisHeader_result = mysqli_query($connection, $getThisHeader) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getThisHeader_result->fetch_assoc()) {
        $lhnHeaderID = $row["headerID"];
		$lhnHeaderTitle = $row["Title"];
		$lhnHeaderLastUpdated = $row["Timestamp"];	
		$lhnHeaderStatus = $row["Status"];	
		$lhnLastEditedBy = $row["username"];	
	}
	
	//adding to array
	array_push($allItemsArray,'
	
		<div class="lhnMenuHeader" headerid="'.$lhnHeaderID.'">
			<div class="lhnMenuHeaderTitle '.$lhnHeaderStatus.'">'.$lhnHeaderTitle.'</div>
			<div class="lhnMenuHeaderLastUpdated">Last Updated: '.$lhnHeaderLastUpdated.' by @'.$lhnLastEditedBy.'</div>
		</div>
	');
		
		//getting links
	$getLinks = "SELECT `Live LHN Links`.`linkID`, `Title`,`Link`,DATE_FORMAT(`Live LHN Links`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp' FROM `Live LHN Links` WHERE `Live LHN Links`.`headerID`='$lhnHeaderID' ORDER BY `Live LHN Links`.`OrderID` ASC";
	$getLinks_result = mysqli_query($connection, $getLinks) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getLinks_result->fetch_assoc()) {
		
			$lhnLinkIDs[]=$row["linkID"];
		
        
	}
		
		
		foreach($lhnLinkIDs as $lhnLinkID){
			
			if (!isset($lhnLinkID)) {
    		array_push($allItemsArray,'EMPTY');
			}
			else {
			$getThisLink = "SELECT `Live LHN Links`.`linkID`,`Live LHN Links`.`headerID`, `Live LHN Links`.`Title`,`Link`,DATE_FORMAT(`Live LHN Links`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp',`Status`,`Href Status`, `username` FROM `Live LHN Links` JOIN `user` ON `Live LHN Links`.`userID` = `user`.`userID` WHERE `Live LHN Links`.`linkID`='$lhnLinkID'";
			$getThisLink_result = mysqli_query($connection, $getThisLink) or die ("Query to get data from Team Project failed: ".mysql_error());
			while($row = $getThisLink_result->fetch_assoc()) {
				$currenLHNLinkID = $row["linkID"];
				$currentLHNLinkStatus = $row["Status"];
				$currentLHNLinkHrefStatus = $row["Href Status"];
				$lhnLinkTitle = $row["Title"];
				$lhnLinkHref = $row["Link"];
				$lhnLinkLastUpdated = $row["Timestamp"];	
				$lhnLinkHeaderID = $row["headerID"];	
				$lhnLastEditedBy = $row["username"];	
				//adding to array
				
				if ($lhnLinkHeaderID == $lhnHeaderID){
					
					
					$lastElement = end($lhnLinkIDs);
					
					if ($lastElement == $currenLHNLinkID) {
					array_push($allItemsArray,'
					<div class="lhnMenuItemContainer last" linkid="'.$currenLHNLinkID.'" headerid="'.$lhnHeaderID.'">
						<div class="lhnMenuItemTitle '.$currentLHNLinkStatus.'">'.$lhnLinkTitle.'</div>
						<div class="lhnMenuItemLink '.$currentLHNLinkHrefStatus.'"">'.$lhnLinkHref.'</div>
						<div class="lhnMenuItemTimestamp">Last Updated: '.$lhnLinkLastUpdated.' by <span>@'.$lhnLastEditedBy.'</span></div>
					</div>');
					}
					else {
						array_push($allItemsArray,'
					<div class="lhnMenuItemContainer" linkid="'.$currenLHNLinkID.'" headerid="'.$lhnLinkHeaderID.'">
						<div class="lhnMenuItemTitle '.$currentLHNLinkStatus.'">'.$lhnLinkTitle.'</div>
						<div class="lhnMenuItemLink '.$currentLHNLinkHrefStatus.'"">'.$lhnLinkHref.'</div>
						<div class="lhnMenuItemTimestamp">Last Updated: '.$lhnLinkLastUpdated.' by <span>@'.$lhnLastEditedBy.'</span></div>
					</div>');
					}
					
					
				}
			
			}
			}
			
			
			
		}
		
		//adding to array
			array_push($allItemsArray,'</div>');
		
	}
	
	//getting all 
	$getPermissions = "SELECT * FROM `Live LHN Permissions` WHERE `lhnID`='$lhnID'";
	$getPermissions_result = mysqli_query($connection, $getPermissions) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getPermissions_result->fetch_assoc()) {
        $permissionUserID[] = $row["userID"];
		
	}
	
	
	if ($myRole === 'Admin') {
		$actions = '<div id="editLHN" class="genericbtn editLHN">Edit</div><div id="newLHNRequest" class="genericbtn newLHNRequest" style="margin-left: 10px;">Mark As Approved</div><div id="setLHNLive" class="genericbtn setLHNLive" style="margin-left: 10px;">Mark As Live</div><a id="giveLHNPermissions" class="genericbtn giveLHNPermissions" style="margin-left: 10px;" data-toggle="modal" data-target="#permissions">Permissions</a><div id="getCode" class="genericbtn getCode" style="margin-left: 10px;">Get Code/Excel File</div><div id="alertTeam" class="genericbtn alertTeam" style="margin-left: 10px;">Alert Team</div>';
	}
	else if ($myRole === 'Editor') {
		$actions = '<div id="editLHN" class="genericbtn editLHN">Edit</div><div id="newLHNRequest" class="genericbtn newLHNRequest" style="margin-left: 10px;">Mark As Approved</div><a id="giveLHNPermissions" class="genericbtn giveLHNPermissions" style="margin-left: 10px;" data-toggle="modal" data-target="#permissions">Permissions</a><div id="getCode" class="genericbtn getCode" style="margin-left: 10px;">Get Code/Excel File</div>';
	}
	else if (in_array($userID, $permissionUserID)){
		$actions = '<div id="editLHN" class="genericbtn editLHN">Edit</div><div id="newLHNRequest" class="genericbtn newLHNRequest" style="margin-left: 10px;">Mark As Approved</div>';
	}
	else {
		$actions = '';
	}
	
	if (!isset($lhnName)) {
		$allItemsArray="<h3 style='margin-top:25px;text-align:center'><em>LHN does not exist.</em></h3>";
		$actions="";
	}
	
////////////
	
	$results = ["printLHN" => $allItemsArray,
				"actions" => $actions];
	
	header('Content-Type: application/json'); 
	echo json_encode($results);
}
if ($type=="reloadHeaderMenu") {
	$lhnHeaderID=$_POST['headerID'];
	//getting headers
	$getHeaders = "SELECT `Live LHN Headers`.`headerID`, `Title`,DATE_FORMAT(`Live LHN Headers`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp', `Status` FROM `Live LHN Headers` WHERE `Live LHN Headers`.`headerID`='$lhnHeaderID'";
	$getHeaders_result = mysqli_query($connection, $getHeaders) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getHeaders_result->fetch_assoc()) {
        $lhnHeaderTitle = $row["Title"];
		$lhnHeaderLastUpdated = $row["Timestamp"];
		$lhnHeaderStatus = $row["Status"];	
	}
	
	$allItemsArray=[];
	
	//adding to array
	array_push($allItemsArray,'
	
		<div class="lhnMenuHeader" headerid="'.$lhnHeaderID.'" id="BLAH">
			<div class="lhnMenuHeaderTitle '.$lhnHeaderStatus.'">'.$lhnHeaderTitle.'</div>
			<div class="lhnMenuHeaderLastUpdated">Last Updated: '.$lhnHeaderLastUpdated.'</div>
		</div>
	');
	
	//getting links
	$getLinks = "SELECT `Live LHN Links`.`linkID`, `Title`,`Link`,DATE_FORMAT(`Live LHN Links`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp' FROM `Live LHN Links` WHERE `Live LHN Links`.`headerID`='$lhnHeaderID' ORDER BY `Live LHN Links`.`OrderID` ASC";
	$getLinks_result = mysqli_query($connection, $getLinks) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getLinks_result->fetch_assoc()) {		
			$lhnLinkIDs[]=$row["linkID"]; 
	}
		
	foreach($lhnLinkIDs as $lhnLinkID){
			
			if (!isset($lhnLinkID)) {
    		array_push($allItemsArray,'EMPTY');
			}
			else {
			$getThisLink = "SELECT `Live LHN Links`.`linkID`,`Live LHN Links`.`headerID`, `Title`,`Link`,DATE_FORMAT(`Live LHN Links`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp',`Status`,`Href Status` FROM `Live LHN Links` WHERE `Live LHN Links`.`linkID`='$lhnLinkID'";
			$getThisLink_result = mysqli_query($connection, $getThisLink) or die ("Query to get data from Team Project failed: ".mysql_error());
			while($row = $getThisLink_result->fetch_assoc()) {
				$currenLHNLinkID = $row["linkID"];
				$currentLHNLinkStatus = $row["Status"];
				$currentLHNLinkHrefStatus = $row["Href Status"];
				$lhnLinkTitle = $row["Title"];
				$lhnLinkHref = $row["Link"];
				$lhnLinkLastUpdated = $row["Timestamp"];	
				$lhnLinkHeaderID = $row["headerID"];	
				//adding to array
				
				if ($lhnLinkHeaderID == $lhnHeaderID){
					
					
					$lastElement = end($lhnLinkIDs);
					
					if ($lastElement == $currenLHNLinkID) {
					array_push($allItemsArray,'
					<div class="lhnMenuItemContainer last" linkid="'.$currenLHNLinkID.'" headerid="'.$lhnHeaderID.'">
						<div class="lhnMenuItemTitle '.$currentLHNLinkStatus.'">'.$lhnLinkTitle.'</div>
						<div class="lhnMenuItemLink '.$currentLHNLinkHrefStatus.'"">'.$lhnLinkHref.'</div>
						<div class="lhnMenuItemTimestamp">Last Updated: '.$lhnLinkLastUpdated.'</div>
					</div>');
					}
					else {
						array_push($allItemsArray,'
					<div class="lhnMenuItemContainer" linkid="'.$currenLHNLinkID.'" headerid="'.$lhnLinkHeaderID.'">
						<div class="lhnMenuItemTitle '.$currentLHNLinkStatus.'">'.$lhnLinkTitle.'</div>
						<div class="lhnMenuItemLink '.$currentLHNLinkHrefStatus.'">'.$lhnLinkHref.'</div>
						<div class="lhnMenuItemTimestamp">Last Updated: '.$lhnLinkLastUpdated.'</div>
					</div>');
					}
					
					
				}
			
			}
			}
			
			
			
		}
	
	//adding to array
	array_push($allItemsArray,'</div>');

	
	
////////////
	
	$results = ["reloadHeaderMenu" => $allItemsArray];
	
	header('Content-Type: application/json'); 
	echo json_encode($results);
}
if ($type=="addLink") {
	$title = addslashes($_POST['linkTitle']);
	$link = addslashes($_POST['linkHref']);
	$headerID=$_POST['headerID'];
	$orderID;
	
	$getCount = "SELECT COUNT(`orderID`) FROM `Live LHN Links` WHERE `headerID`='$headerID'";
	$getCount_result = mysqli_query($connection, $getCount) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getCount_result->fetch_assoc()) {
		$thisCount = $row["COUNT(`orderID`)"];
		
		if ($thisCount == 0) {
			$orderID = 0;
		}
		else {
			//getting order number 
			$getLast = "SELECT `orderID` FROM `Live LHN Links` WHERE `headerID`='$headerID' ORDER BY `orderID` DESC LIMIT 1";
			$getLast_result = mysqli_query($connection, $getLast) or die ("Query to get data from Team Project failed: ".mysql_error());
			while($row = $getLast_result->fetch_assoc()) {

					$orderID = $row["orderID"]+1;

			}
		}
	}
	
	
	
	$insert = mysqli_query($connection,"INSERT INTO `Live LHN Links`(`lhnID`, `headerID`, `Title`, `Link`, `orderID`, `userID`, `Status`, `Href Status`) VALUES('$lhnID','$headerID','$title','$link','$orderID','$userID','newAdded','newAdded')");
	
}
if ($type=="addHeader") {
	$title = addslashes($_POST['title']);
	
	//getting order number 
	$getLast = "SELECT IFNULL((SELECT `orderID` FROM `Live LHN Headers` WHERE `lhnID`='$lhnID' ORDER BY `orderID` DESC LIMIT 1) ,'0');";
	$getLast_result = mysqli_query($connection, $getLast) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getLast_result->fetch_assoc()) {
        if ($row["orderID"] == 0) {
			$orderID = "0";
		}
		else {
			$orderID = $row["orderID"]+1;
		}
	}
	
	$insert = mysqli_query($connection,"INSERT INTO `Live LHN Headers`(`lhnID`, `Title`, `orderID`, `userID`, `Status`) VALUES('$lhnID','$title','$orderID','$userID','newAdded')");
	
	$headerID = mysqli_insert_id($connection);
	
	////////////
	
	$results = ["headerID" => $orderID];
	
	header('Content-Type: application/json'); 
	echo json_encode($results);
	
}
if ($type=="removeLink") {
	$headerID=$_POST['headerID'];
	$linkID=$_POST['linkID'];
	
	$getCurrentStatus = "SELECT * FROM `Live LHN Links` WHERE `linkID`='$linkID'";
			$getCurrentStatus_result = mysqli_query($connection, $getCurrentStatus) or die ("Query to get data from Team Project failed: ".mysql_error());
			while($row = $getCurrentStatus_result->fetch_assoc()) {
				$status = $row["Status"];
				$hrefStatus = $row["Href Status"];

			}
			
			$keepOrdered;
			
			if (strpos($status, 'reordered') !== false) {
				$keepOrdered=" reordered";
			}
			else {
				$keepOrdered="";
			}
	
	
	$update = mysqli_query($connection,"UPDATE `Live LHN Links` SET `Status`='removedStrike".$keepOrdered."',`Href Status`='removedStrike',`Timestamp`=now(),`userID`='$userID' WHERE `linkID`= '$linkID'");
	
}
if ($type=="removeAllHeaderMenu") {
	$headerID=$_POST['headerID'];
	
	$update = mysqli_query($connection,"UPDATE `Live LHN Links` SET `Status`='removedStrike',`Href Status`='removedStrike',`Timestamp`=now(),`userID`='$userID' WHERE `headerID`= '$headerID'");
	$update2 = mysqli_query($connection,"UPDATE `Live LHN Headers` SET `Status`='removedStrike',`Timestamp`=now(),`userID`='$userID' WHERE `headerID`= '$headerID'");
	
}
if ($type=="updateLinkTitle") {
	$headerID=$_POST['headerID'];
	$linkID=$_POST['linkID'];
	$title=addslashes($_POST['linkTitle']);
	$className=$_POST['className'];
	
	$getCurrentStatus = "SELECT * FROM `Live LHN Links` WHERE `linkID`='$linkID'";
			$getCurrentStatus_result = mysqli_query($connection, $getCurrentStatus) or die ("Query to get data from Team Project failed: ".mysql_error());
			while($row = $getCurrentStatus_result->fetch_assoc()) {
				$status = $row["Status"];
				$hrefStatus = $row["Href Status"];

			}
			
			$keepOrdered;
			
			if (strpos($status, 'reordered') !== false) {
				$keepOrdered=" reordered";
			}
			else {
				$keepOrdered="";
			}

	$update = mysqli_query($connection,"UPDATE `Live LHN Links` SET `Status`='$className".$keepOrdered."',`Title`='$title',`Timestamp`=now(),`userID`='$userID' WHERE `linkID`= '$linkID'");
	
}
if ($type=="updateLinkHref") {
	$headerID=$_POST['headerID'];
	$linkID=$_POST['linkID'];
	$title=$_POST['linkTitle'];
	$className=$_POST['className'];
	
	$getCurrentStatus = "SELECT * FROM `Live LHN Links` WHERE `linkID`='$linkID'";
			$getCurrentStatus_result = mysqli_query($connection, $getCurrentStatus) or die ("Query to get data from Team Project failed: ".mysql_error());
			while($row = $getCurrentStatus_result->fetch_assoc()) {
				$status = $row["Status"];
				$hrefStatus = $row["Href Status"];

			}
	
	$keepOrdered;
			
			if (strpos($hrefStatus, 'reordered') !== false) {
				$keepOrdered=" reordered";
			}
			else {
				$keepOrdered="";
			}
	
	$update = mysqli_query($connection,"UPDATE `Live LHN Links` SET `Href Status`='$className".$keepOrdered."',`Link`='$title',`Timestamp`=now(),`userID`='$userID' WHERE `linkID`= '$linkID'");
	
}
if ($type=="updateHeaderTitle") {
	$headerID=$_POST['headerID'];
	$title=addslashes($_POST['title']);
	$className=$_POST['className'];
	
	$update = mysqli_query($connection,"UPDATE `Live LHN Headers` SET `Status`='$className',`Title`='$title',`Timestamp`=now(),`userID`='$userID' WHERE `headerID`= '$headerID'");
	
}
if($type == 'saveOrder'){
	$headerID=$_POST['headerID'];
	$linkID_array = explode(",",$_POST['linkID_array']);
	
		$count = 0;
        foreach ($linkID_array as $id){
			
			$getCurrentStatus = "SELECT * FROM `Live LHN Links` WHERE `linkID`='$id'";
			$getCurrentStatus_result = mysqli_query($connection, $getCurrentStatus) or die ("Query to get data from Team Project failed: ".mysql_error());
			while($row = $getCurrentStatus_result->fetch_assoc()) {
				$status = $row["Status"];
				$hrefStatus = $row["Href Status"];

			}
			
			$keepTitle;
			$keepHref;
			
			if (strpos($status, 'updatedTitle') !== false) {
				$keepTitle="updatedTitle ";
			}
			else if (strpos($status, 'newAdded') !== false) {
				$keepTitle="newAdded ";
			}
			else if (strpos($status, 'removedStrike') !== false) {
				$keepTitle="removedStrike ";
			}
			else {
				$keepTitle="";
			}
			
			if (strpos($hrefStatus, 'updatedHref') !== false) {
				$keepHref="updatedHref ";
			}
			else if (strpos($hrefStatus, 'newAdded') !== false) {
				$keepHref="newAdded ";
			}
			else if (strpos($hrefStatus, 'removedStrike') !== false) {
				$keepHref="removedStrike ";
			}
			else {
				$keepHref="";
			}
			
			
			$query2 = "UPDATE `Live LHN Links` SET `orderID` = '$count', `Status` = '".$keepTitle."reordered', `Href Status` = '".$keepHref."reordered',`userID`='$userID' WHERE `linkID` = '$id'";
			$query2_result = mysqli_query($connection, $query2) or die ("Query to get data from Team task failed: ".mysql_error());
			$count ++;    
        }
		
}
if($type == 'saveHeaderOrder'){
	
	$headerID_array = explode(",",$_POST['headerID_array']);
	
		$count = 0;
        foreach ($headerID_array as $id){
			
			$getCurrentStatus = "SELECT * FROM `Live LHN Headers` WHERE `headerID`='$id'";
			$getCurrentStatus_result = mysqli_query($connection, $getCurrentStatus) or die ("Query to get data from Team Project failed: ".mysql_error());
			while($row = $getCurrentStatus_result->fetch_assoc()) {
				$status = $row["Status"];
				
			}
			
			$keepTitle;
			
			if (strpos($status, 'updatedTitle') !== false) {
				$keepTitle="updatedTitle ";
			}
			else if (strpos($status, 'newAdded') !== false) {
				$keepTitle="newAdded ";
			}
			else if (strpos($status, 'removedStrike') !== false) {
				$keepTitle="removedStrike ";
			}
			else {
				$keepTitle="";
			}
			
			
			
			
			$query2 = "UPDATE `Live LHN Headers` SET `orderID` = '$count', `Status` = '".$keepTitle."reordered',`Timestamp`=now(),`userID`='$userID' WHERE `headerID` = '$id'";
			$query2_result = mysqli_query($connection, $query2) or die ("Query to get data from Team task failed: ".mysql_error());
			$count ++;    
        }
		
}
if ($type=="markApproved") {
	
	//getting all 
	$getAll = "SELECT `Live LHNs`.`lhnID`, `Title`,DATE_FORMAT(`Live LHNs`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp' FROM `Live LHNs` WHERE `Live LHNs`.`lhnID`='$lhnID'";
	$getAll_result = mysqli_query($connection, $getAll) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getAll_result->fetch_assoc()) {
        $lhnName = addslashes($row["Title"]);
		$lhnNameNoInsert = $row["Title"];
		$lhnLastUpdated = $row["Timestamp"];
	}

	$update = mysqli_query($connection,"UPDATE `Live LHNs` SET `Status`='Approved',`Timestamp`=now() WHERE `lhnID`= '$lhnID'");
	
	/////////// INSERTING ACTIVITY IN ACTIVITY FEED ///////////
	$activity = "submitted a <strong>$lhnName LHN</strong> request.";
	$addActivity = "INSERT INTO `Activity Feed`(`Activity`, `Type`, `userID`, `lhnID`) VALUES ('$activity','LHN','$userID','$lhnID')";
	$addActivity_result = mysqli_query($connection, $addActivity) or die ("Query7 failed: ".mysql_error());
	
	
	if ($userID != '1') {
		$notification = "<a href=/dashboard/requests/lhn/?lhnID=$lhnID>A new <strong>$lhnName</strong> LHN Request has been submitted by <strong>@$username2</strong>.</a>";
	
			$addNotification = "INSERT INTO `Notifications`(`Notification`, `Type`, `userID`) VALUES ('$notification','Ticket','1')";
		$addNotification_result = mysqli_query($connection, $addNotification) or die ("notifications to get data from Team Project failed: ".mysql_error());
	}
	
	
	
	//////// SENDING EMAIL TO CANDICE ///////	
	//getting members
	$getProjectMember = "SELECT * FROM `user` WHERE `userID` = '1'";
	$getProjectMember_result = mysqli_query($connection, $getProjectMember) or die ("getNotes_result to get data from Team Project failed: ".mysql_error());
	while($row = mysqli_fetch_array($getProjectMember_result)) {
		$projectMember =$row["email"];
		$projectMemberFN = $row["First Name"];
		$projectMemberPP = $row["PP Link"];
	}
	
	$subject = "A new $lhnNameNoInsert LHN Request has been submitted by $FN $LN.";
	
		$to = $projectMember;
		$message = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
'.$emailCss.'
</head>

<body bgcolor="#f7f7f7">
<table align="center" cellpadding="0" cellspacing="0" class="container-for-gmail-android" width="100%">
  <tr>
    <td align="left" valign="top" width="100%">
      <center>
      
        <table cellspacing="0" cellpadding="0" width="100%" bgcolor="#ffffff">
          <tr>
            <td width="100%" height="80" valign="top" style="text-align: center; vertical-align:middle;">
            
              <center>
                <table cellpadding="0" cellspacing="0" width="600" class="w320">
                  <tr>
                    <td class="pull-left mobile-header-padding-left" style="vertical-align: middle;">
                      <a href="https://dashboard.coat.com/dashboard">Dashboard</a>
                    </td>
                    <td align="right" class="pull-right mobile-header-padding-right" style="color: #4d4d4d;">
                      <a href="https://dashboard.coat.com/dashboard/users/my-profile/"><table width="110" border="0" cellspacing="0" cellpadding="1" style="float:right">
					  <tbody>
						<tr>
						  <td align="right"><a href="https://dashboard.coat.com/dashboard/users/my-profile/">My Profile</a></td>
						</tr>
					  </tbody>
					</table>
                      </a>
                    </td>
                  </tr>
                </table>
              </center>
              
            </td>
          </tr>
        </table>
      </center>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" width="100%" style="background-color: #f7f7f7;" class="content-padding">
      <center>
        <table cellspacing="0" cellpadding="0" width="600" class="w320">
          <tr>
            <td class="header-lg">
              A new <strong>'.$lhnNameNoInsert.'</strong> LHN Request has been submitted.
            </td>
          </tr>
          <tr>
            <td class="free-text">
              '.$FN.' '.$LN.' submitted a new '.$lhnNameNoInsert.' LHN request.
              <br><br>
             
             
             <a href="https://dashboard.coat.com/dashboard/requests/lhn/?lhnID='.$lhnID.'" class="button">View LHN</a>
              <br><br>
            </td>
          </tr>
          
        </table>
      </center>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" width="100%" style="background-color: #ffffff;  border-top: 1px solid #e5e5e5; border-bottom: 1px solid #e5e5e5;">
      <center>
        
      </center>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" width="100%" style="background-color: #f7f7f7; height: 100px;">
      <center>
        <table cellspacing="0" cellpadding="0" width="600" class="w320">
          <tr>
            <td style="padding: 25px 0 25px">
              DO NOT RESPOND TO THIS EMAIL!<br>If you are having any issues, please contact Candice Garrett @ <a href="mailto:candice.garrett@burlingtonstores.com">candice.garrett@burlingtonstores.com</a> directly.<br /><br />
            </td>
          </tr>
        </table>
      </center>
    </td>
  </tr>
</table>

</body>
</html>';
	
	if ($userID != '1') {
		mail($to, $subject, $message, $headers);
	}
		

	
	

	
}
if ($type=="markInProcess") {
	
	//getting all 
	$getAll = "SELECT `Live LHNs`.`lhnID`, `Title`,DATE_FORMAT(`Live LHNs`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp' FROM `Live LHNs` WHERE `Live LHNs`.`lhnID`='$lhnID'";
	$getAll_result = mysqli_query($connection, $getAll) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getAll_result->fetch_assoc()) {
        $lhnName = addslashes($row["Title"]);
		
		$lhnLastUpdated = $row["Timestamp"];
	}

	$update = mysqli_query($connection,"UPDATE `Live LHNs` SET `Status`='In Process',`Timestamp`=now() WHERE `lhnID`= '$lhnID'");

}
if ($type == "getUsernames") {
	
	$searchTerm = $_POST["typedUsername"];
	
	$foundUsernames = getUserTagsNotInLHN($searchTerm,$lhnID);
	
	////////////
	$results = ["foundUsernames" => $foundUsernames];
	
	header('Content-Type: application/json'); 
	echo json_encode($results);
}
if ($type=="newAccessCheckUsername") {
	$reviewer = $_POST['username'];
	$reviewerUserID = $_POST['newMemberUserID'];
	$lhnID = $_POST['lhnID'];
	
	$query56 = "SELECT * FROM `user` WHERE NOT EXISTS (SELECT * FROM `Live LHN Permissions` WHERE `lhnID`='$lhnID' AND `userID` ='$reviewerUserID')";
	$query56_result = mysqli_query($connection, $query56) or die ("Query to get data from Team task failed: ".mysql_error());
	
	while ($row = mysqli_fetch_array($query56_result)) {
		$reviewerEmail = $row["email"];
		$finalUserID = $row["userID"];
	}
	
	if (!isset($finalUserID)) {
		echo "User does not exist or the user is already added.";
		exit;
	}
	else {
		
	}
}
if ($type == "getAccessList") {
	$lhnID = $_POST["lhnID"];
	
	$query ="SELECT DISTINCT `username`,`user`.`userID` FROM `Live LHN Permissions` JOIN `user` ON `Live LHN Permissions`.`userID`=`user`.`userID` WHERE `lhnID` = '$lhnID' ORDER BY `username` ASC";
	$query_result = mysqli_query($connection, $query) or die ("Query to get data from Team task failed: ".mysql_error());
		
	while ($row = mysqli_fetch_array($query_result)) {
	$showAccessible[] = '<li userid="'.$row['userID'].'"><span>'.$row['username'].'</span><i class="fa fa-trash pull-right removeReviewer"></i></li>';

	}
	
	if(count($showAccessible) == 0) {
		$showAccessible=null;
	}
	
	////////////
	$results = ["showAccessible" => $showAccessible];
	
	header('Content-Type: application/json'); 
	echo json_encode($results);
}
if ($type=="giveAccess") {
	$members = json_decode($_POST['members'], true);
	
	//getting lhn info
	//getting all 
	$getAll = "SELECT `Live LHNs`.`lhnID`, `Title`,DATE_FORMAT(`Live LHNs`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp' FROM `Live LHNs` WHERE `Live LHNs`.`lhnID`='$lhnID'";
	$getAll_result = mysqli_query($connection, $getAll) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getAll_result->fetch_assoc()) {
        $lhnName = addslashes($row["Title"]);
		
		$lhnLastUpdated = $row["Timestamp"];
	}
	
	
	if (isset($members)) {
		foreach($members as $val){
		$query4 = "INSERT INTO `Live LHN Permissions`(`lhnID`, `userID`) VALUES ('$lhnID','$val')";
		$query4_result = mysqli_query($connection, $query4) or die ("Query3 failed: ".mysql_error());
			
			
		}
	}
}
if ($type=="removeAccess") {
	$thisUserID=$_POST['thisUserID'];
	//getting lhn info
	//getting all 
	$getAll = "SELECT `Live LHNs`.`lhnID`, `Title`,DATE_FORMAT(`Live LHNs`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp' FROM `Live LHNs` WHERE `Live LHNs`.`lhnID`='$lhnID'";
	$getAll_result = mysqli_query($connection, $getAll) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getAll_result->fetch_assoc()) {
        $lhnName = addslashes($row["Title"]);
		
		$lhnLastUpdated = $row["Timestamp"];
	}
	
	
	
	
	$query = "DELETE FROM `Live LHN Permissions` WHERE `userID` = '$thisUserID' AND `lhnID` = '$lhnID'";
	$query_result = mysqli_query($connection, $query) or die ("Query to get data from Team Project failed: ".mysql_error());

		
	
}
if ($type=="markAsLive") {
	
	//getting all 
	$getAll = "SELECT `Live LHNs`.`lhnID`, `Title`,DATE_FORMAT(`Live LHNs`.`Timestamp`, '%l:%i %p %b %e, %Y') AS 'Timestamp' FROM `Live LHNs` WHERE `Live LHNs`.`lhnID`='$lhnID'";
	$getAll_result = mysqli_query($connection, $getAll) or die ("Query to get data from Team Project failed: ".mysql_error());
	while($row = $getAll_result->fetch_assoc()) {
        $lhnName = addslashes($row["Title"]);
		
		$lhnLastUpdated = $row["Timestamp"];
	}

	$update = mysqli_query($connection,"UPDATE `Live LHNs` SET `Status`='Live',`Timestamp`=now() WHERE `lhnID`= '$lhnID'");
	
	//HEADERS
	
	//deleting headers
	$deleteHeaders = "DELETE FROM `Live LHN Headers` WHERE `Status` LIKE '%removedStrike%' AND `lhnID` = '$lhnID'";
	$deleteHeaders_result = mysqli_query($connection, $deleteHeaders) or die ("Query to get data from Team Project failed: ".mysql_error());
	//updating remaining
	$updateHeaders = mysqli_query($connection,"UPDATE `Live LHN Headers` SET `Status`='Live' WHERE `lhnID`= '$lhnID'");

	//LINKS
	$deleteLinks = "DELETE FROM `Live LHN Links` WHERE `Status` LIKE '%removedStrike%' AND `lhnID` = '$lhnID'";
	$deleteLinks_result = mysqli_query($connection, $deleteLinks) or die ("Query to get data from Team Project failed: ".mysql_error());
	//updating remaining
	$updateLinks = mysqli_query($connection,"UPDATE `Live LHN Links` SET `Status`='Live',`Href Status`='Live' WHERE `lhnID`= '$lhnID'");
	
	/////////// INSERTING ACTIVITY IN ACTIVITY FEED ///////////
	$activity = "pushed the <strong>$lhnName LHN</strong> live.";
	$addActivity = "INSERT INTO `Activity Feed`(`Activity`, `Type`, `userID`, `lhnID`) VALUES ('$activity','LHN','$userID','$lhnID')";
	$addActivity_result = mysqli_query($connection, $addActivity) or die ("Query7 failed: ".mysql_error());

	
}
if ($type=="alertTeam") {
	
	//SENDING NOTIFICATION
	//getting members in db
	$query3 = "SELECT DISTINCT `user`.`userID` FROM `Live LHN Permissions` JOIN `user` ON `Live LHN Permissions`.`userID` = `user`.`userID` WHERE `user`.`userID` != '$userID'";
	$query3_result = mysqli_query($connection, $query3) or die ("Query4 failed: ".mysql_error());
	
	while($row = $query3_result->fetch_assoc()) {
		$memberUserIDs[]=$row["userID"];
	}
	
	foreach ($memberUserIDs as $name) {
		$notification = "<a href=/dashboard/requests/lhn>All LHNs have been pushed live. Please review the site in 15 minutes.</a>";
	
		$addNotification = "INSERT INTO `Notifications`(`Notification`, `Type`, `userID`, `lhnID`) VALUES ('$notification','Ticket','$name',null)";
		$addNotification_result = mysqli_query($connection, $addNotification) or die ("Query6 failed: ".mysql_error());
		
		if (isset($name)) {
			//////// SENDING EMAIL ///////	
	//getting members
	$getProjectMember = "SELECT * FROM `user` WHERE `userID` = '$name'";
	$getProjectMember_result = mysqli_query($connection, $getProjectMember) or die ("getNotes_result to get data from Team Project failed: ".mysql_error());
	while($row = mysqli_fetch_array($getProjectMember_result)) {
		$projectMember =$row["email"];
		$projectMemberFN = $row["First Name"];
		$projectMemberPP = $row["PP Link"];
	}
	
	$subject = "All LHNs have been pushed live.";
	
		$to = $projectMember;
		$message = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
'.$emailCss.'
</head>

<body bgcolor="#f7f7f7">
<table align="center" cellpadding="0" cellspacing="0" class="container-for-gmail-android" width="100%">
  <tr>
    <td align="left" valign="top" width="100%">
      <center>
     
        <table cellspacing="0" cellpadding="0" width="100%" bgcolor="#ffffff">
          <tr>
            <td width="100%" height="80" valign="top" style="text-align: center; vertical-align:middle;">
           
              <center>
                <table cellpadding="0" cellspacing="0" width="600" class="w320">
                  <tr>
                    <td class="pull-left mobile-header-padding-left" style="vertical-align: middle;">
                      <a href="https://dashboard.coat.com/dashboard">Dashboard</a>
                    </td>
                    <td align="right" class="pull-right mobile-header-padding-right" style="color: #4d4d4d;">
                      <a href="https://dashboard.coat.com/dashboard/users/my-profile/"><table width="110" border="0" cellspacing="0" cellpadding="1" style="float:right">
					  <tbody>
						<tr>
						  <td align="right"><a href="https://dashboard.coat.com/dashboard/users/my-profile/">My Profile</a></td>
						</tr>
					  </tbody>
					</table>
                      </a>
                    </td>
                  </tr>
                </table>
              </center>
              
            </td>
          </tr>
        </table>
      </center>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" width="100%" style="background-color: #f7f7f7;" class="content-padding">
      <center>
        <table cellspacing="0" cellpadding="0" width="600" class="w320">
          <tr>
            <td class="header-lg">
              All LHNs has been pushed live.
            </td>
          </tr>
          <tr>
            <td class="free-text">
              <br>'.$FN.' '.$LN.' just pushed the LHNs live. Please allow up to 15 minutes for the cache to clear.
              <br><br>
             
             
             <a href="https://dashboard.coat.com/dashboard/requests/lhn/" class="button">View LHNs</a>
              <br><br>
            </td>
          </tr>
          
        </table>
      </center>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" width="100%" style="background-color: #ffffff;  border-top: 1px solid #e5e5e5; border-bottom: 1px solid #e5e5e5;">
      <center>
        
      </center>
    </td>
  </tr>
  <tr>
    <td align="center" valign="top" width="100%" style="background-color: #f7f7f7; height: 100px;">
      <center>
        <table cellspacing="0" cellpadding="0" width="600" class="w320">
          <tr>
            <td style="padding: 25px 0 25px">
              DO NOT RESPOND TO THIS EMAIL!<br>If you are having any issues, please contact Candice Garrett @ <a href="mailto:candice.garrett@burlingtonstores.com">candice.garrett@burlingtonstores.com</a> directly.<br /><br />
            </td>
          </tr>
        </table>
      </center>
    </td>
  </tr>
</table>

</body>
</html>';
	
	
		mail($to, $subject, $message, $headers);
	
			
		}
	}
	
}

?>