<?php 
include_once('../../header.php');


?>
   <html>
    <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php echo $stylesjs ?>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->


<script src="/dashboard/js/csvExport.js"></script>

<script src="/dashboard/js/ckeditor/ckeditor.js"></script>
<script>
$(document).ready(function() {

function showCaret() {
	//$('.mobileNavLinkContainer ul li:has(ul)').find("span").append('<i class="fa fa-chevron-right" aria-hidden="true"></i>');
	//$( ".mobileNavLinkContainer ul li:has(.child)" ).find("span").append('<i class="fa fa-chevron-right" aria-hidden="true"></i>');
	
	$( ".mobileNavLinkContainer ul li:has(.child)" ).each(function() {
		//if ($(this).children("ul").length) {
			$(this).find("span").first().append('<i class="fa fa-chevron-right" aria-hidden="true"></i>');
		//	}
  		
	});
}

function showNextLevel(thisElement) {
	$(".mobileNavLinkContainer li").removeClass("activeNav");
	
	var categoryID = $(".mobileNavHeader").attr("categoryid");
	var parentID = thisElement.attr("parentid");
	var levelID = thisElement.attr("levelid");
	var linkID = thisElement.attr("linkid");
	var prevLevelID = levelID-1;

	if (!parentID) {
		parentID = categoryID;
	}
	
	console.log("parentID:" +parentID);
	console.log("levelID:" +levelID);
	console.log("prevLevelID:" +prevLevelID);
	console.log("categoryID:" +categoryID);
	console.log("linkID:" +linkID);
	
	$("#back").attr("levelID",levelID).attr("parentID",parentID).attr("title",$(".currentLevelTitle").text());
	
	thisElement.addClass("activeNav");
	
	$('li[categoryid="'+categoryID+'"][levelid="'+levelID+'"]').not(".activeNav").hide();
	
	$(".activeNav").find("span").first().hide();
	$(".activeNav").children().not("span").show();
	$(".activeNav").css("box-shadow","none");
	$(".activeNav").removeAttr("style");
	$(".activeNav").show("slide", { direction: "right" }, 500);
	$(".activeNav").find("ul.child").show().find('li').show("slide", { direction: "right" }, 500);
	$("#back").show();
	
	//$(".currentLevelTitle").html(thisElement.find("span").first().text());
	//thisElement.find("span").first().hide();
	//thisElement.css("box-shadow","none");
	//$('.mobileNavLinkContainer li').hide();
	//thisElement.show();
	//$('li[categoryid="'+categoryID+'"][linkid="'+parentID+'"]').show();
	//thisElement.find('ul.child li').removeAttr("style");
	//thisElement.find('ul.child').first().show("slide", { direction: "right" }, 500);
	//$("#back").show();
}
	
function goBackALevel(levelID,thisElement) {
	var categoryID = $(".mobileNavHeader").attr("categoryid");
	var parentID = thisElement.attr("parentid");
	var activeLevel = $(".activeNav");
	var linkID = activeLevel.attr("linkid");
	
	var prevLevelID = thisElement.attr("levelid");
	var prevprevLevelID = levelID -1;
	var nextLevelID = levelID + 1;
	
	
	console.log("parentID:" +parentID);
	console.log("levelID:" +levelID);
	console.log("prevLevelID:" +prevLevelID);
	console.log("categoryID:" +categoryID);
	console.log("linkID:" +linkID);
	
	$("#back").attr("levelID",nextLevelID).attr("parentID",parentID);
	
	
$('li[categoryid="'+categoryID+'"][linkid="'+parentID+'"][levelid="'+nextLevelID+'"]').addClass("activeNav");
	
	//level3
	//activeLevel.parent().parent().parent().find('li').show("slide", { direction: "left" }, 500);
	
	$(".mobileNavLinkContainer li").removeClass("activeNav");
	
	if (levelID == 1) {
		$("#back").hide();
		var categoryMainTitle = $(".mobileNavHeader").attr("categorytitle");
		$(".currentLevelTitle").html(categoryMainTitle);
		$(".mobileNavLinkContainer li").first().addClass("activeNav");
		
		activeLevel.find("span").first().show();
		activeLevel.children().not("span").hide();
		activeLevel.removeAttr("style").hide();
		$('li[levelid="'+levelID+'"]').closest('.child').hide();
		activeLevel.closest("ul:not(.child)").find('li').show("slide", { direction: "left" }, 500);
	}
	
	if (levelID == 2) {
		var parentTitle = $("#back").attr("title");
		$(".currentLevelTitle").html(parentTitle);
		$('[categoryid="'+categoryID+'"][levelid="'+levelID+'"][linkid="'+prevLevelID+'"]').addClass("activeNav");
		alert(parentTitle);
		
		$(".activeNav").find("span").first().show();
		$(".activeNav").children().not("span").hide();
		$(".activeNav").removeAttr("style").hide();
		$(".activeNav").find("ul.child").show().find('li').show("slide", { direction: "left" }, 500);
		//$(".activeNav").closest("ul:not(.child)").find('li').show("slide", { direction: "left" }, 500);

		}
	else {
		var parentTitle = $("#back").attr("title");
		$(".currentLevelTitle").html(parentTitle);
		
	}
	
	
	
	
}
	
showCaret();
	
$(document).on('click','.mobileNavLinkContainer ul li:has(ul)', function(e) {
	e.stopPropagation();
	showNextLevel($(this));
	
		
});	
	
$(document).on('click','#back', function() {
	var levelID = $(this).attr("levelid");
	goBackALevel(levelID,$(this));
		
});	


	

});
	

</script>
    </head>

    <body>
    
<nav class="navbar navbar-default" style="background:#ffffff; border:none;">
  <div class="container-fluid">
   <?php include("../../templates/topNav.php") ?>
  </div><!-- /.container-fluid -->
</nav>
<div class="container-fluid">
	<div class="row">
        <?php include("../../templates/lhn.php") ?>
       
       <div class="col-sm-10" style="height: 100%;">
      <div class="row">
     	<div class="col-sm-12">
			<?php include("../../templates/alerts.php") ?>
		</div>
		</div>
     	<div class="row">
		 <div class="col-sm-12">
			<div class="whitebg">
    	 		
    	 		
					<div class="header">
						<?php 
						if ($myRole === 'Admin' || $myRole === 'Editor' ) {
						echo '<a href="admin" class="genericbtn" style="float:right;margin-top:-10px;margin-left:20px;">Admin</a>';
						}
						?>
						<div id="faq" class="genericbtn" style="float:right;margin-top:-10px;background:#ff0000" data-toggle="modal" data-target="#howto">How-To</div>
					<h3>Mobile Navigation Requests</h3>
					
					</div>
				
					<p>Total Changes: <span>2</span></p>
					<p>Level 1 Changes: <span>2</span></p>
					<p>Level 2 Changes: <span>2</span></p>
					<p>Level 3 Changes: <span>2</span></p>
					<p>Level 4 Changes: <span>2</span></p>
				
				
					<div id="edit" class="genericbtn">Edit Current Level</div>
					<br>
					<div id="mobileNavContainer">
						<div class="mobileNavHeader" categoryid="1" categorytitle="Coats">
							<div id="back"><i class="fa fa-chevron-left" aria-hidden="true"></i>
 <span>Back</span></div>
							<span class="currentLevelTitle">Coats</span>
							
						</div>
						<div class="mobileNavLinkContainer">
							<ul class="main">
								<li categoryid="1" levelid="1" linkid="1"><span>Shop All Coats</span></li>
								<li categoryid="1" levelid="1" linkid="2"><span>Warmth Ratings</span>
									<ul class="child">
										<li parentid="2" levelid="2" linkid="1"><span>Mild</li>
										<li parentid="2" levelid="2" linkid="2"><span>Cold</li>
										<li parentid="2" levelid="2" linkid="3"><span>Extreme</li>
									</ul>
								</li>
								<li categoryid="1" levelid="1" linkid="3"><span>Womens Coats</span>
									<ul class="child">
										<li parentid="3" levelid="2" linkid="1"><span>Active Jackets</span>
											<ul class="child">
												<li parentid="1" levelid="3" linkid="1"><span>level 2 item 1</span></li>
												<li parentid="1" levelid="3" linkid="2"><span>level 2 item 2</span></li>
												<li parentid="1" levelid="3" linkid="3"><span>level 2 item 3</span></li>
											</ul>
										</li>
											
										<li parentid="3" levelid="2" linkid="2"><span>Fall Jackets</span></li>
										<li parentid="3" levelid="2" linkid="3"><span>Parkas</span></li>
									</ul>
								</li>
								<li categoryid="1" levelid="1" linkid="4"><span>Mens Coats</span>
									<ul class="child">
										<li parentid="4" levelid="2" linkid="1"><span>blah</span></li>
										<li parentid="4" levelid="2" linkid="2"><span>blah 2</span></li>
										<li parentid="4" levelid="2" linkid="3"><span>blah 3</span></li>
									</ul>
								</li>
								<li categoryid="1" levelid="1" linkid="5"><span>Girls Coats</span>
									<ul class="child">
										<li parentid="5" levelid="2" linkid="1"><span>Mild</span></li>
										<li parentid="5" levelid="2" linkid="2"><span>Cold</span></li>
										<li parentid="5" levelid="2" linkid="3"><span>Extreme</span></li>
									</ul>
								</li>
								<li categoryid="1" levelid="1" linkid="6"><span>Boys Coats</span>
									<ul class="child">
										<li parentid="6" levelid="2" linkid="1"><span>Mild</span></li>
										<li parentid="6" levelid="2" linkid="2"><span>Cold</span></li>
										<li parentid="6" levelid="2" linkid="3"><span>Extreme</span></li>
									</ul>
								</li>
								<li categoryid="1" levelid="1" linkid="7"><span>Special Sizes</span>
									<ul class="child">
										<li parentid="7" levelid="2" linkid="1"><span>Mild</span></li>
										<li parentid="7" levelid="2" linkid="2"><span>Cold</span></li>
										<li parentid="7" levelid="2" linkid="3"><span>Extreme</span></li>
									</ul>
								</li>
								<li categoryid="1" levelid="1" linkid="8"><span>Clearance</span></li>
							</ul>
						</div>
				
				
				
				
					</div>
				
				
				
				
					<div id="specialRequestOverview">
						<div id="overviewAction">
							<h3 class="text-center">Overview</h3>
							<div class="expandIcon"><i class="fa fa-plus" aria-hidden="true"></i></div>
						</div>
						<br>
						<div class="row" id="overviewHide">
							<div class="col-sm-4">
								
								<div class="srContainer">
									<div class="srHeading srInProcess">
										<h3>In Process <span></span></h3>
									</div>
									
									<div class="srContent">
										
									</div>
								
								</div>
							</div>
							
							<div class="col-sm-4">
								<div class="srContainer">
									<div class="srHeading srApproved">
										<h3>Approved <span></span></h3>
									</div>
									<div class="srContent">
										
									</div>
								
								</div>
							</div>
							
							<div class="col-sm-4">
								<div class="srContainer">
									<div class="srHeading srLive">
										<h3>Live <span></span></h3>
									</div>
									<div class="srContent">
										
									</div>
								
								</div>
							</div>
						</div>
				
					</div>
				
				
				<div id="srMainContent">
					<hr>
					<div class="row">
						
						<div class="col-sm-9 text-center">
							<div id="actions"></div>
						</div>
						<div class="col-sm-3">
							
							<div class="keyContainer">
						<table class="key" cellpadding="9">
							<th><h5 style="margin:0px 0px;font-weight:bold;">Key:</h5><hr style="margin: 10px 0px;width: 100%;"></th>
							<tr>
								
								<td class="newAdded">Addition/Updated</td>
							</tr>
							<tr>
								<td class="removedStrike">Remove</td>
							</tr>
							<tr>
								<td class="reordered">Reorder</td>
							</tr>
						</table>	
						</div>
						</div>
					</div>
				<div class="row" style="margin-top: 25px;">
					
						<div class="col-sm-12">
							
						<div id="lhnCodeContainer">
							<h3>Code:</h3>
          				<textarea id="lhnCode"></textarea>
							<div id="copyCode" class="genericbtn">Copy Code</div>
						</div>
								
							
							<div class="lhnContainer" id="printLHN">
								
								
									
							
							
							
							</div>
							<br><br>
           				</div>
     	 			</div>	
           			
				</div>
    	 		<br><br>
   	 	   </div>
     	 	
     	 	 
		 </div>	
     	
     	
     	
     	</div>
     
       </div>
       
      
	</div>
</div>    


   
</div>  
	   
<!-- PERMISSIONS MODAL --->	   
 <div class="modal fade" id="permissions" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <a type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></a>
        <h4 class="modal-title" id="myModalLabel">Permissions</h4>
      </div>
      <div class="modal-body">
        		<div class="form-sm">
        			<div class="row">
						<div class="col-sm-12">
						<div class="formLabels">Access Granted To:</div> 
						<ol id="showAccessible" class="showAccessEmails"></ol>
						</div>
					</div>
      				<div class="row">
      					<div class="col-sm-12">
							<br>
							<div class="formLabels">Give Access To: (USE THE @ SYMBOL TO FIND A USER.)</div>
							<div id="showUsernames"></div>
      						<input type="text" id="giveAccessTo" name="giveAccessTo" placeholder="Enter the reviewer's @username here.">
							
						<br>
						<ol class="accessEmails"></ol>
							<br>
							<div class="genericbtn" id="giveAccess">Add</div>
						</div>
						
						
					</div>
      				
       				
        		
      			
		
     			</div>
      </div>
      
    </div>
  </div>
</div>  
	 <!-- HOW TO MODAL --->	   
 <div class="modal fade" id="howto" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <a type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></a>
        <h4 class="modal-title" id="myModalLabel">How to Make A Request</h4>
      </div>
      <div class="modal-body">
		  <h4>General</h4>
        	<h5><strong>How to Edit</strong></h5>	
		  <ol>
			  <li>Select an LHN from the overview panel.</li>
		  	<li>Click the blue <strong>"Edit"</strong> button. (If you do not see it, you do not have access to this item. Please contact Candice Garrett for access.)</li>
		  </ol>
		  
		  <h5><strong>How to Submit for Build</strong></h5>	
		  <ol>
			  <li>After you have made all of your changes, click "Mark As Approved". A notification/email will be sent to Candice Garrett indicating the changes have been finalized. If you have changes afterwards, please contact Candice Garrett.<br><br>*You are able to make changes throughout the week until you are ready to submit. Changes are automatically saved. Only click "Mark As Approved" when ALL changes have been finalized. </li>
		</ol>
		  
		  <h5><strong>Process</strong></h5>	
		  <ol>
			  <li>After your changes, Click "Mark As Approved".</li>
			  <li>Candice Garrett will be notified, and build will begin.</li>
			  <li>When it is live, you will be sent a confirmation email reminding you to review in production.</li>
			  <li>Changes will be reflected in the request on the Dashboard.</li>
		</ol>
		  
		  
		  
		  <hr>
		  <h4>Headers</h4>
		  
		  <h5><strong>How to Add A Header</strong></h5>	
		  <ol>
			  <li>Click the blue <strong>"Add New Heading Section"</strong> button at the bottom of the LHN.</li>
		  	<li>Enter the header title in the input box and click the checkmark. (Click the "x" to cancel.)</li>
		  </ol>
		  
		  <h5><strong>How to Change the Header Titles</strong></h5>	
		  <ol>
			  <li>Double click the desired header title.</li>
		  	<li>Enter the updated title in the input box and click outside of the box.</li>
		  </ol>
		  
		  <h5><strong>How to Remove An Entire Heading Section</strong></h5>	
		  <ol>
			  <li>Click the red <strong>"Remove"</strong> button at the bottom of your desired heading section.</li>
		  	<li>Click the red <strong>Remove</strong> Symbol next to the header title. (Click "Cancel" to cancel.)</li>
		  </ol>
		  
		  <h5><strong>How to Reorder Heading Section Sections</strong></h5>	
		  <ol>
			  <li>Click the blue <strong>"Reorder Heading Sections"</strong> button at the top left corner of the request.</li>
		  	<li>Click and hold the <strong>gray icon</strong> next to the header title to control the entire section. Drag to desired location.</li>
			  <li>Click the blue <strong>"Done"</strong> button at the top left corner of the request.</li>
		  </ol>
		  
		  
		  
		  <hr>
		  <h4>Links</h4>
		  
		  <h5><strong>How to Add A Link</strong></h5>	
		  <ol>
			  <li>Click the green <strong>"Add"</strong> button at the bottom of your desired heading section.</li>
		  	<li>Enter the link title and path in the input boxes and click the checkmark. (Click the "x" to cancel.)</li>
		  </ol>
		  
		  <h5><strong>How to Change the Link Titles and Link Paths</strong></h5>	
		  <ol>
			  <li>Double click the desired link title or link path.</li>
		  	<li>Enter the updated title or path in the input box and click outside of the box.</li>
		  </ol>
		  
		  <h5><strong>How to Remove An Individual Links</strong></h5>	
		  <ol>
			  <li>Click the red <strong>"Remove"</strong> button at the bottom of your desired heading section.</li>
		  	<li>Click the red <strong>Remove</strong> Symbol next to the desired link item. (Click "Cancel" to cancel.)</li>
		  </ol>
		  
		  <h5><strong>How to Reorder Individual Links Within Sections</strong></h5>	
		  <ol>
			  <li>Click the blue <strong>"Reorder"</strong> button at the bottom of your desired heading section.</li>
		  	<li>Click and hold the <strong>gray icon</strong> next to the link item to control the entire link. Drag to desired location in that section.</li>
			  <li>Click the blue <strong>"Save"</strong> at the bottom of your desired heading section.</li>
		  </ol>
		  
      </div>
      
    </div>
  </div>
</div>    
    <?php echo $scripts?>
<input type="hidden" id="lhnSelectionHeader">
    </body>
</html>